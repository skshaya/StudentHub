<?php


$url="localhost";
$dbuser="root";
$dbpass="";
$dbname="alumnihub";

/*
$url="sql208.epizy.com";
$dbuser="epiz_22071684";
$dbpass="qwerty123";
$dbname="epiz_22071684_studenthub";
*/
?>