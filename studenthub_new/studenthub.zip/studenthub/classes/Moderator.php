<?php

class Moderator extends User{
    
    public function __construct() {
        
    }

    
}
