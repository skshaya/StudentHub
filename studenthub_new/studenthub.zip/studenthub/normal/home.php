<html>
<head>
</head>
<body>
<form action ="connect.php" method="post">
<input type="text" name="searchq" placeholder="search here">
<input type="submit" value="search" name="submit"/>
</form>
</body>
</html>